import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "./AuthContext";

const ProtectedRoute = ({ allowedRoles }) => {
  const { user, loading } = useAuth();

  if (loading) return null; // Muestra un spinner si prefieres

  return user && allowedRoles.includes(user.role) ? <Outlet /> : <Navigate to="/login" replace />;
};

export default ProtectedRoute;
